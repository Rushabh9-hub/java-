class loop
{
	public static void main(String args[])
	{
		int i;
		for(i=1;i<=10;i++)
		{
			System.out.println("Rushu");
		}
		
		for(i=1;i<=10;i++);
		{
			System.out.println("i");
		}
		
		for(i=1;i<=10;++i)
		{
			System.out.println("Rushabh");
		}
		
		
	}
}